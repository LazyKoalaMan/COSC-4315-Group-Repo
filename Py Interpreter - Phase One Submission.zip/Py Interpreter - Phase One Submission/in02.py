##Basic Arithmetic and Comments


a = 3
b = 2
c = 20
d = 50
# Perform addition
resultSum = a + b + c + d

# print result
print("Sum =", resultSum)
