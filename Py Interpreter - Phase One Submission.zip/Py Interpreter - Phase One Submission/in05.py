# Test Case for: Multiplication with variables

a = 10
b = 2
c = 3

resA = b * c + b * a + a * c

resB = a + b + c + a * b * c

#print
print("resA =", resA)
print("resB =", resB)
