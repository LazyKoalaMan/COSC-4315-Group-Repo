The algorithm and essential code for the infixToPostFix function was taken from https://www.geeksforgeeks.org/convert-infix-expression-to-postfix-expression/
The algorithm and essential code for the evaluatePostFix function was taken from https://www.geeksforgeeks.org/evaluation-of-postfix-expression/
Otherwise, Scanner.h is based upon the Java-based interpreter for Lox that is described in "Crafting Interpreters" by Robert Nystrom.

the program can be compiled and executed with:
g++ mypthon.cpp -o mypython
./mypython <file.py>