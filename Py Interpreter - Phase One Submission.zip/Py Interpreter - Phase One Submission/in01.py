#variable assignments and comments

#comments
a = 3

b = 2
#re assign
a = 1

#print results
print("a =", a)
print("b =", b)




