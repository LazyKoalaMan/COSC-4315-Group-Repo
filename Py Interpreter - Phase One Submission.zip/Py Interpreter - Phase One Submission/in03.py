#test cases for multiplciation with values

# Perform operations
a = 3 * 4 * 10 * 1 * 2
b = 10 * 20 * 1 * 2 * 3

# Print results
print("a =", a)
print("b =", b)
