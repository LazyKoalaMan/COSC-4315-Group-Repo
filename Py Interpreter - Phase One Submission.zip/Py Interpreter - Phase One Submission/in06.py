#Test Case for: if ==

a = 12
b = 2
c = 3

d = b + c 
resB = a * c + 5 + b

z = 0

#Check if condition to set z to 1

if resB == 43:
    z = 1

print("z = ", z)
