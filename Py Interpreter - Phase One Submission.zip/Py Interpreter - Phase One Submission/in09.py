# TestCase for:if-else with <


x = 15 
y = 21
a = y * x + y + x
b = a * 2 

# if-else condition
if b < 10 :
    res = 1  
else:
    res = 0  

print("res =", res)
