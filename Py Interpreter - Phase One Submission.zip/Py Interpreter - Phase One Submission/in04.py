# Test Case for: Multiplication and addition 

a = 100 + 2 * 3 * 4 * 5 + 12
b = 10 * 2 + 3 * 5 + 4 * 6 + 1 * 2
c = 10 + 20 + 30 + 40 + 50 + 1 * 60

#print
print("a =", a)
print("b =", b)
print("c =", c)


