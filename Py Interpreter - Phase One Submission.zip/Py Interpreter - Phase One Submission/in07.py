# TestCase for: 2 if ==

x1 = 5
y1 = x1 + 3 + 7
z1 = x1 * 2 + y1 


# if condition
resA = 0
resB = 0
if y1  == 15:
    resA = 1 


if z1 == 4:
    resB = 1

print("resA =", resA)
print("resB =", resB)
