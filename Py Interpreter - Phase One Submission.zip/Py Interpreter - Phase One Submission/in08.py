# TestCase for:if-else with <=

x = 5
y = 2
a = x + y

# if-else condition
if a <= 3:
    resA = 1
else:
    resA = 0 

resB = 5
b = y + y

if b == 4:
    resB = 1

print("resA =", resA)
print("resB =", resB)
